import React, { useState } from 'react'
import axios from 'axios'

export default function Signuppage(props) {
  const [userInfo, setUserInfo] = useState({})

  const handleChange = (e) => {
    setUserInfo({
      ...userInfo,
      [e.target.name]: e.target.value
    })
  }
  const handleSubmit = (e) => {
    e.preventDefault()
    axios.post('http://localhost:' + (props.user === 'doctor' ? '8082' : '8081') + '/reg', //'http://localhost:8082/reg'
    userInfo) 
            .then((Responce) => {
                console.log(Responce.data)
                alert('Succesfully SignedUp')
            })
            .catch((err) => {
                console.log(err)
                console.log(err.Responce)
                alert('Please Try again')


            })
  }

    return (
      // https://24j1q8gzma4rsuat1tbzospi-wpengine.netdna-ssl.com/wp-content/uploads/2017/11/NewsletterSignup-Background.jpg
      <div style={{
        background: "linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url('https://img.freepik.com/free-vector/employer-meeting-job-applicant-pre-employment-assessment-employee-evaluation-assessment-form-report-performance-review-concept-illustration_335657-2058.jpg?t=st=1652184855~exp=1652185455~hmac=6bca30d94a816c68a15e87629edd62c8198847837a8496bd964679959e2e2104&w=1060')",
        backgroundRepeat: 'no-repeat',
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        minHeight: 'calc(100vh - 110px)',
        paddingBottom: '7vh',
        }}>
        <h1 className='text-white' style={{
                textShadow: '2px 2px 6px rgba(0,0,0,0.65)',
            }}>Sign Up Form</h1>
        <div className='container'>
          <div className='row justify-content-center'>
            <div className='col-md-6'>
              <div className='card shadow bg-light'>
                <div className='card-body'>
                  {/* <button className='btn btn-primary btn-block'
                  onClick={() => {
                    setUserInfo({})
                    props.user === 'doctor' ? props.setUser('admin') : props.setUser('doctor') ;
                  }} >{props.user}</button> */}
                  
                  <form onSubmit={handleSubmit}>
                    <div class="form-group text-left">
                      <label for="name">name</label>
                      <input type='adminname' class="form-control" value={
                        userInfo.adminname || userInfo.doctorname || ''
                      } name={props.user === 'doctor' ? 'doctorname' : 'adminname'} placeholder={ props.user === 'doctor' ? 'Enter Doctor name' : 'Enter Admin name' } required onChange={handleChange} />

                    </div>
                    <div class="form-group text-left">
                      <label for="Password">Password</label>
                      <input type='password' class="form-control" value={
                        userInfo.password === undefined ? '' : userInfo.password
                      } name='password' placeholder='password' required onChange={handleChange} />
                    </div>
                    <div class="form-group text-left">
                      <label for="emailid">emailid</label>
                      <input type='emailid' class="form-control" value={
                        userInfo.emailid === undefined ? '' : userInfo.emailid
                      } name='emailid' placeholder='emailid' required onChange={handleChange} />
                    </div>
                    <div class="form-group text-left">
                      <label for="contactno">contactno</label>
                      <input type='contactno' class="form-control" value={
                        userInfo.contactno === undefined ? '' : userInfo.contactno
                      } name='contactno' placeholder='contactno' required onChange={handleChange} />
                    </div>
                    <button class="btn btn-primary" onSubmit={handleSubmit}>SignUp</button>
                  </form>
                </div>
              </div>
            </div>
          </div>

        </div>
      </div>
    )
  
}
