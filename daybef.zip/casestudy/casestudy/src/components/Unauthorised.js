import React from "react";


export default function Unauthorised() {
    return (
        <div className="container mt-5">
            <div className="row mb-2 justify-content-end mx-0">
                <div className="col-md-12">
                    <div className="alert alert-danger" role="alert">
                        <h4 className="alert-heading">You are not authorised to view this page</h4>
                        <p>
                            Please login to view this page
                        </p>
                        <hr />
                        <p className="mb-0">
                            <a href="/login" className="btn btn-primary">Login</a>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    )
}